jquery.easyPaginate
===================

jQuery plugin to paginate anything with cool effect (or not)

Documentation
---------------------
Check out the [documentation](http://st3ph.github.io/jquery.easyPaginate) to find out how easyPaginate works.

About
---------------------
easyPaginate is a [jQuery](http://jquery.com) plugin who allowed you to paginate anything with some built in cool effect

Compatibility
-------------
Testing and working well with Chrome, Opera, Firefox, Safari and Internet Explorer

License
---------------------
Dual licensed under the MIT or GPL Version 2 licenses :
[http://www.opensource.org/licenses/mit-license.php](http://www.opensource.org/licenses/mit-license.php)
[http://www.opensource.org/licenses/GPL-2.0](http://www.opensource.org/licenses/GPL-2.0)